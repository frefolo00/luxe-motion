// Main application initialization
class LuxeMotionApp {
    constructor() {
        this.initialized = false;
        this.setupThemeSwitcher();
    }

    setupThemeSwitcher() {
        // Load saved theme or default to dark
        const savedTheme = localStorage.getItem('luxe-motion-theme') || 'dark';
        this.setTheme(savedTheme);

        // Setup theme switcher event listeners
        document.querySelectorAll('.theme-option').forEach(button => {
            button.addEventListener('click', () => {
                const theme = button.dataset.theme;
                this.setTheme(theme);
                localStorage.setItem('luxe-motion-theme', theme);
            });
        });
    }

    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        
        // Update active theme button
        document.querySelectorAll('.theme-option').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-theme="${theme}"]`).classList.add('active');
    }

    async init() {
        try {
            // Show loading
            showLoading('Inicializando aplicación...');

            // Register service worker for PWA functionality
            await this.registerServiceWorker();

            // Initialize database
            await window.luxeDB.init();

            // Initialize camera manager
            await window.cameraManager.init();

            // Initialize UI manager (already created in ui.js)
            // window.uiManager is already available

            // Initialize auth manager (already created in auth.js)
            // window.authManager is already available

            // Initialize export manager (already created in export.js)
            // window.exportManager is already available

            this.initialized = true;
            hideLoading();

            console.log('✅ Luxe Motion App initialized successfully');
        } catch (error) {
            console.error('❌ Error initializing app:', error);
            hideLoading();
            alert('Error al inicializar la aplicación');
        }
    }

    async registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            try {
                const registration = await navigator.serviceWorker.register('./service-worker.js');
                console.log('Service Worker registered:', registration);
                
                // Handle install prompt
                this.handleInstallPrompt();
            } catch (error) {
                console.error('Service Worker registration failed:', error);
            }
        }
    }

    handleInstallPrompt() {
        let deferredPrompt;

        window.addEventListener('beforeinstallprompt', (e) => {
            // Prevent Chrome 67 and earlier from automatically showing the prompt
            e.preventDefault();
            // Stash the event so it can be triggered later
            deferredPrompt = e;
            
            // Show install banner after successful login
            if (window.authManager && window.authManager.isUserAuthenticated()) {
                this.showInstallBanner(deferredPrompt);
            }
        });

        // Handle the install button click
        window.addEventListener('appinstalled', () => {
            console.log('PWA was installed');
            deferredPrompt = null;
        });
    }

    showInstallBanner(deferredPrompt) {
        // Create install banner
        const banner = document.createElement('div');
        banner.id = 'installBanner';
        banner.innerHTML = `
            <div style="
                position: fixed;
                bottom: 20px;
                left: 20px;
                right: 20px;
                background: linear-gradient(135deg, var(--primary-blue), #004499);
                color: white;
                padding: 15px 20px;
                border-radius: 12px;
                box-shadow: 0 4px 20px rgba(195, 0, 16, 0.3);
                display: flex;
                justify-content: space-between;
                align-items: center;
                z-index: 1000;
                animation: slideUp 0.3s ease-out;
            ">
                <div>
                    <strong>¡Instala Luxe Motion!</strong>
                    <br>
                    <small>Accede rápidamente desde tu pantalla de inicio</small>
                </div>
                <div>
                    <button id="installBtn" style="
                        background: rgba(255,255,255,0.2);
                        border: 1px solid rgba(255,255,255,0.3);
                        color: white;
                        padding: 8px 16px;
                        border-radius: 8px;
                        margin-right: 10px;
                        cursor: pointer;
                    ">Instalar</button>
                    <button id="dismissBtn" style="
                        background: none;
                        border: none;
                        color: white;
                        cursor: pointer;
                        font-size: 18px;
                    ">×</button>
                </div>
            </div>
        `;

        document.body.appendChild(banner);

        // Add slide up animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideUp {
                from { transform: translateY(100px); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);

        // Handle install button click
        document.getElementById('installBtn').addEventListener('click', async () => {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                const { outcome } = await deferredPrompt.userChoice;
                console.log(`User response to the install prompt: ${outcome}`);
                deferredPrompt = null;
            }
            document.body.removeChild(banner);
        });

        // Handle dismiss button click
        document.getElementById('dismissBtn').addEventListener('click', () => {
            document.body.removeChild(banner);
        });

        // Auto-hide after 10 seconds
        setTimeout(() => {
            if (document.getElementById('installBanner')) {
                document.body.removeChild(banner);
            }
        }, 10000);
    }

    // Utility methods
    isOnline() {
        return navigator.onLine;
    }

    handleNetworkChange() {
        window.addEventListener('online', () => {
            console.log('App is online');
        });

        window.addEventListener('offline', () => {
            console.log('App is offline');
        });
    }

    // Error handling
    setupErrorHandling() {
        window.addEventListener('error', (event) => {
            console.error('Global error:', event.error);
        });

        window.addEventListener('unhandledrejection', (event) => {
            console.error('Unhandled promise rejection:', event.reason);
        });
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', async () => {
    const app = new LuxeMotionApp();
    await app.init();
    
    // Setup network change handling
    app.handleNetworkChange();
    
    // Setup error handling
    app.setupErrorHandling();
    
    // Make app instance available globally for debugging
    window.luxeMotionApp = app;
});

// Prevent zoom on iOS Safari when focusing inputs
document.addEventListener('gesturestart', function (e) {
    e.preventDefault();
});

// Handle back button on Android
window.addEventListener('popstate', (event) => {
    // Handle navigation within the app
    if (window.authManager && window.authManager.isUserAuthenticated()) {
        // If we're in a sub-screen, go back to dashboard
        const currentScreen = document.querySelector('.screen.active');
        if (currentScreen && currentScreen.id !== 'dashboardScreen') {
            window.uiManager.showDashboard();
        }
    }
});

// Global utility functions
window.formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency: 'EUR'
    }).format(amount);
};

window.formatDate = (date) => {
    return new Intl.DateTimeFormat('es-ES').format(new Date(date));
};

// Console welcome message
console.log(`
🏎️ LUXE MOTION - Gestión de Alquileres
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Aplicación inicializada correctamente
🔒 Acceso seguro con autenticación
📱 PWA instalable
💾 Almacenamiento local con IndexedDB
📸 Captura de fotos con cámara
📊 Exportación PDF/Excel
🎨 Diseño responsive y moderno

Desarrollado para uso privado exclusivo.
`);

console.log('🚀 Luxe Motion App v1.0.0 - Ready to roll!');