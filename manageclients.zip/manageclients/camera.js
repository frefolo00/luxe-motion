// Camera Management with flexible photo options
class CameraManager {
    constructor() {
        this.stream = null;
        this.currentCamera = 'user'; // 'user' for front camera, 'environment' for back camera
        this.video = null;
        this.canvas = null;
        this.currentPhotoType = null;
        this.captureCallback = null;
    }

    async init() {
        this.video = document.getElementById('cameraVideo');
        this.canvas = document.getElementById('cameraCanvas');
        this.modal = document.getElementById('cameraModal');
        
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Capture button
        document.getElementById('captureBtn').addEventListener('click', () => {
            this.capturePhoto();
        });

        // Switch camera button
        document.getElementById('switchCameraBtn').addEventListener('click', () => {
            this.switchCamera();
        });

        // Close camera button
        document.getElementById('closeCameraBtn').addEventListener('click', () => {
            this.closeCamera();
        });

        // Retake photo button
        document.getElementById('retakeBtn').addEventListener('click', () => {
            this.retakePhoto();
        });

        // Confirm photo button
        document.getElementById('confirmBtn').addEventListener('click', () => {
            this.confirmPhoto();
        });

        // Close modal on outside click
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.closeCamera();
            }
        });

        // Face photo capture
        document.getElementById('captureFaceBtn').addEventListener('click', () => {
            this.showPhotoOptions('face', 'Foto del Rostro');
        });

        // ID front capture
        document.getElementById('captureIdFrontBtn').addEventListener('click', () => {
            this.showPhotoOptions('idFront', 'DNI Frontal');
        });

        // ID back capture
        document.getElementById('captureIdBackBtn').addEventListener('click', () => {
            this.showPhotoOptions('idBack', 'DNI Trasero');
        });
    }

    showPhotoOptions(photoType, title) {
        this.currentPhotoType = photoType;
        
        // Create options modal
        const optionsModal = document.createElement('div');
        optionsModal.className = 'modal active';
        optionsModal.id = 'photoOptionsModal';
        optionsModal.innerHTML = `
            <div class="modal-content photo-options-modal">
                <div class="camera-header">
                    <h3>${title}</h3>
                    <button class="btn-close" onclick="this.closest('.modal').remove()">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="18" y1="6" x2="6" y2="18"/>
                            <line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                    </button>
                </div>
                <div class="photo-options">
                    <button class="photo-option-btn" onclick="window.cameraManager.openCamera('${photoType}', '${title}'); this.closest('.modal').remove();">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                            <circle cx="12" cy="13" r="4"/>
                        </svg>
                        <span>Tomar Foto</span>
                    </button>
                    <button class="photo-option-btn" onclick="window.cameraManager.selectFromGallery('${photoType}'); this.closest('.modal').remove();">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                            <circle cx="9" cy="9" r="2"/>
                            <path d="M21 15l-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>
                        </svg>
                        <span>Seleccionar de Galería</span>
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(optionsModal);
    }

    selectFromGallery(photoType) {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.style.display = 'none';
        
        input.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    this.updatePhotoPreview(photoType, event.target.result);
                };
                reader.readAsDataURL(file);
            }
        });
        
        document.body.appendChild(input);
        input.click();
        document.body.removeChild(input);
    }

    async openCamera(photoType, title) {
        this.currentPhotoType = photoType;
        document.getElementById('cameraTitle').textContent = `Capturar ${title}`;
        
        try {
            await this.startCamera();
            this.modal.classList.add('active');
            this.showCameraView();
        } catch (error) {
            console.error('Error accessing camera:', error);
            alert('No se pudo acceder a la cámara. Por favor, verifica los permisos.');
        }
    }

    async startCamera() {
        try {
            // Stop any existing stream
            if (this.stream) {
                this.stream.getTracks().forEach(track => track.stop());
            }

            const constraints = {
                video: {
                    facingMode: this.currentCamera,
                    width: { ideal: 1280 },
                    height: { ideal: 720 }
                }
            };

            this.stream = await navigator.mediaDevices.getUserMedia(constraints);
            this.video.srcObject = this.stream;
        } catch (error) {
            console.error('Error starting camera:', error);
            throw error;
        }
    }

    async switchCamera() {
        this.currentCamera = this.currentCamera === 'user' ? 'environment' : 'user';
        await this.startCamera();
    }

    showCameraView() {
        document.getElementById('cameraContainer').style.display = 'block';
        document.getElementById('photoPreviewContainer').style.display = 'none';
        document.getElementById('cameraControls').style.display = 'flex';
        document.getElementById('photoControls').style.display = 'none';
    }

    showPreviewView(imageData) {
        document.getElementById('cameraContainer').style.display = 'none';
        document.getElementById('photoPreviewContainer').style.display = 'block';
        document.getElementById('cameraControls').style.display = 'none';
        document.getElementById('photoControls').style.display = 'flex';
        
        const previewImg = document.getElementById('photoPreviewImg');
        previewImg.src = imageData;
    }

    capturePhoto() {
        if (!this.video || !this.canvas) return;

        const context = this.canvas.getContext('2d');
        
        // Set canvas dimensions to match video
        this.canvas.width = this.video.videoWidth;
        this.canvas.height = this.video.videoHeight;
        
        // Draw the video frame to canvas
        context.drawImage(this.video, 0, 0);
        
        // Get the image data as base64
        const imageData = this.canvas.toDataURL('image/jpeg', 0.8);
        
        // Show preview
        this.showPreviewView(imageData);
        this.currentCapturedImage = imageData;
    }

    retakePhoto() {
        this.showCameraView();
    }

    confirmPhoto() {
        if (this.currentCapturedImage) {
            this.updatePhotoPreview(this.currentPhotoType, this.currentCapturedImage);
            this.closeCamera();
        }
    }

    updatePhotoPreview(photoType, imageData) {
        let previewElement;
        
        switch (photoType) {
            case 'face':
                previewElement = document.getElementById('facePhotoPreview');
                break;
            case 'idFront':
                previewElement = document.getElementById('idFrontPreview');
                break;
            case 'idBack':
                previewElement = document.getElementById('idBackPreview');
                break;
        }
        
        if (previewElement) {
            previewElement.innerHTML = `
                <img src="${imageData}" alt="${photoType}">
                <div class="photo-overlay">
                    <button class="btn-change-photo" onclick="window.cameraManager.showPhotoOptions('${photoType}', '${this.getPhotoTitle(photoType)}')">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                            <circle cx="12" cy="13" r="4"/>
                        </svg>
                    </button>
                </div>
            `;
            
            // Store the image data for form submission
            previewElement.dataset.imageData = imageData;
        }
    }

    getPhotoTitle(photoType) {
        switch (photoType) {
            case 'face': return 'Foto del Rostro';
            case 'idFront': return 'DNI Frontal';
            case 'idBack': return 'DNI Trasero';
            default: return 'Foto';
        }
    }

    closeCamera() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
        
        this.modal.classList.remove('active');
        this.currentPhotoType = null;
        this.currentCapturedImage = null;
    }

    // Get captured photos data
    getCapturedPhotos() {
        const facePhoto = document.getElementById('facePhotoPreview').dataset.imageData;
        const idFrontPhoto = document.getElementById('idFrontPreview').dataset.imageData;
        const idBackPhoto = document.getElementById('idBackPreview').dataset.imageData;
        
        return {
            facePhoto,
            idFrontPhoto,
            idBackPhoto
        };
    }

    // Reset all photo previews
    resetPhotos() {
        const facePreview = document.getElementById('facePhotoPreview');
        const idFrontPreview = document.getElementById('idFrontPreview');
        const idBackPreview = document.getElementById('idBackPreview');
        
        facePreview.innerHTML = `
            <div class="photo-placeholder">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
                    <circle cx="12" cy="13" r="4"/>
                </svg>
                <span>Capturar Foto</span>
            </div>
        `;
        
        idFrontPreview.innerHTML = `
            <div class="photo-placeholder">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                    <line x1="8" y1="21" x2="16" y2="21"/>
                    <line x1="12" y1="17" x2="12" y2="21"/>
                </svg>
                <span>DNI Frontal</span>
            </div>
        `;
        
        idBackPreview.innerHTML = `
            <div class="photo-placeholder">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                    <line x1="8" y1="21" x2="16" y2="21"/>
                    <line x1="12" y1="17" x2="12" y2="21"/>
                </svg>
                <span>DNI Trasero</span>
            </div>
        `;
        
        // Clear stored data
        delete facePreview.dataset.imageData;
        delete idFrontPreview.dataset.imageData;
        delete idBackPreview.dataset.imageData;
    }
}

// Create global camera manager instance
window.cameraManager = new CameraManager();