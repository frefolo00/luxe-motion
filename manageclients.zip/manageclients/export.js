// Export functionality for PDF and Excel
class ExportManager {
    constructor() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        document.getElementById('exportPdfBtn').addEventListener('click', () => {
            this.exportToPDF();
        });

        document.getElementById('exportExcelBtn').addEventListener('click', () => {
            this.exportToExcel();
        });
    }

    async exportToPDF() {
        try {
            showLoading('Generando PDF...');
            
            const clients = await window.luxeDB.getAllClients();
            
            if (clients.length === 0) {
                hideLoading();
                alert('No hay clientes para exportar');
                return;
            }

            // Create PDF content
            const pdf = await this.generatePDFContent(clients);
            
            // Download the PDF
            const blob = new Blob([pdf], { type: 'application/pdf' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `luxe-motion-clientes-${new Date().toISOString().split('T')[0]}.pdf`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            hideLoading();
        } catch (error) {
            console.error('Error exporting PDF:', error);
            hideLoading();
            alert('Error al generar el PDF');
        }
    }

    async generatePDFContent(clients) {
        // Simple PDF generation without external libraries
        // This is a basic implementation - in a real app you'd use a library like jsPDF
        
        let content = `
        %PDF-1.4
        1 0 obj
        <<
        /Type /Catalog
        /Pages 2 0 R
        >>
        endobj
        
        2 0 obj
        <<
        /Type /Pages
        /Kids [3 0 R]
        /Count 1
        >>
        endobj
        
        3 0 obj
        <<
        /Type /Page
        /Parent 2 0 R
        /MediaBox [0 0 612 792]
        /Resources <<
        /Font <<
        /F1 4 0 R
        >>
        >>
        /Contents 5 0 R
        >>
        endobj
        
        4 0 obj
        <<
        /Type /Font
        /Subtype /Type1
        /BaseFont /Helvetica
        >>
        endobj
        
        5 0 obj
        <<
        /Length 6 0 R
        >>
        stream
        BT
        /F1 18 Tf
        50 750 Td
        (LUXE MOTION - REPORTE DE CLIENTES) Tj
        0 -30 Td
        `;

        // Add client data
        let yPos = 700;
        clients.forEach((client, index) => {
            if (yPos < 100) {
                // Start new page (simplified)
                yPos = 750;
            }
            
            content += `
            /F1 12 Tf
            50 ${yPos} Td
            (Cliente ${index + 1}: ${client.name}) Tj
            0 -20 Td
            (Coche: ${client.carModel} | Fecha: ${client.startDate} | Total: ${client.totalPrice}€) Tj
            0 -30 Td
            `;
            
            yPos -= 50;
        });

        content += `
        ET
        endstream
        endobj
        
        6 0 obj
        ${content.split('stream')[1].split('endstream')[0].length}
        endobj
        
        xref
        0 7
        0000000000 65535 f 
        0000000010 00000 n 
        0000000079 00000 n 
        0000000173 00000 n 
        0000000301 00000 n 
        0000000380 00000 n 
        trailer
        <<
        /Size 7
        /Root 1 0 R
        >>
        startxref
        ${content.length}
        %%EOF
        `;

        return content;
    }

    async exportToExcel() {
        try {
            showLoading('Generando Excel...');
            
            const clients = await window.luxeDB.getAllClients();
            
            if (clients.length === 0) {
                hideLoading();
                alert('No hay clientes para exportar');
                return;
            }

            // Generate CSV content (Excel compatible)
            let csvContent = 'data:text/csv;charset=utf-8,';
            
            // Headers
            csvContent += 'Nombre,Fecha Inicio,Duración (días),Coche,Fianza (€),Precio/día (€),Total (€),Fecha Registro\n';
            
            // Data rows
            clients.forEach(client => {
                const row = [
                    `"${client.name}"`,
                    client.startDate,
                    client.duration,
                    `"${client.carModel}"`,
                    client.deposit,
                    client.pricePerDay,
                    client.totalPrice,
                    new Date(client.createdAt).toLocaleDateString()
                ].join(',');
                
                csvContent += row + '\n';
            });

            // Create and download file
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement('a');
            link.setAttribute('href', encodedUri);
            link.setAttribute('download', `luxe-motion-clientes-${new Date().toISOString().split('T')[0]}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            hideLoading();
        } catch (error) {
            console.error('Error exporting Excel:', error);
            hideLoading();
            alert('Error al generar el archivo Excel');
        }
    }

    // Export individual client to PDF
    async exportClientToPDF(clientId) {
        try {
            showLoading('Generando PDF del cliente...');
            
            const client = await window.luxeDB.getClient(clientId);
            
            if (!client) {
                hideLoading();
                alert('Cliente no encontrado');
                return;
            }

            // Generate PDF for single client with photos
            const pdf = await this.generateClientPDFContent(client);
            
            // Download the PDF
            const blob = new Blob([pdf], { type: 'application/pdf' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `luxe-motion-${client.name.replace(/\s+/g, '-').toLowerCase()}.pdf`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            hideLoading();
        } catch (error) {
            console.error('Error exporting client PDF:', error);
            hideLoading();
            alert('Error al generar el PDF del cliente');
        }
    }

    async generateClientPDFContent(client) {
        // This would include client photos and detailed information
        // For simplicity, we're creating a basic PDF structure
        
        const content = `
        LUXE MOTION - FICHA DE CLIENTE
        
        Nombre: ${client.name}
        Fecha de inicio: ${client.startDate}
        Duración: ${client.duration} días
        Coche alquilado: ${client.carModel}
        Fianza: ${client.deposit}€
        Precio por día: ${client.pricePerDay}€
        Total: ${client.totalPrice}€
        
        Registrado el: ${new Date(client.createdAt).toLocaleDateString()}
        `;
        
        return content;
    }
}

// Helper functions for loading states
function showLoading(message = 'Cargando...') {
    const loadingOverlay = document.getElementById('loadingOverlay');
    loadingOverlay.querySelector('p').textContent = message;
    loadingOverlay.classList.add('active');
}

function hideLoading() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    loadingOverlay.classList.remove('active');
}

// Create global export manager instance
window.exportManager = new ExportManager();