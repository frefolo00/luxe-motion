// Authentication Manager
class AuthManager {
    constructor() {
        this.isAuthenticated = false;
        this.correctPassword = 'Adam10';
        this.setupEventListeners();
        this.checkAuthStatus();
    }

    setupEventListeners() {
        const loginForm = document.getElementById('loginForm');
        const logoutBtn = document.getElementById('logoutBtn');
        
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });
        
        logoutBtn.addEventListener('click', () => {
            this.handleLogout();
        });

        // Handle Enter key in password field
        document.getElementById('passwordInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.handleLogin();
            }
        });
    }

    async handleLogin() {
        const passwordInput = document.getElementById('passwordInput');
        const errorMessage = document.getElementById('loginError');
        const password = passwordInput.value.trim();

        // Clear previous error
        errorMessage.textContent = '';
        
        if (password === this.correctPassword) {
            // Successful login
            this.isAuthenticated = true;
            await this.saveAuthStatus();
            this.showDashboard();
            passwordInput.value = '';
        } else {
            // Failed login
            errorMessage.textContent = 'Contraseña incorrecta';
            passwordInput.value = '';
            passwordInput.focus();
            
            // Add shake animation
            passwordInput.style.animation = 'shake 0.5s ease-in-out';
            setTimeout(() => {
                passwordInput.style.animation = '';
            }, 500);
        }
    }

    async handleLogout() {
        this.isAuthenticated = false;
        await this.clearAuthStatus();
        this.showLogin();
    }

    async saveAuthStatus() {
        // Save authentication status to session storage (not persistent across browser restarts for security)
        sessionStorage.setItem('luxe_motion_auth', 'true');
        sessionStorage.setItem('luxe_motion_auth_time', Date.now().toString());
    }

    async clearAuthStatus() {
        sessionStorage.removeItem('luxe_motion_auth');
        sessionStorage.removeItem('luxe_motion_auth_time');
    }

    async checkAuthStatus() {
        const isAuth = sessionStorage.getItem('luxe_motion_auth');
        const authTime = sessionStorage.getItem('luxe_motion_auth_time');
        
        // Check if authentication is valid and not expired (8 hours)
        if (isAuth === 'true' && authTime) {
            const timeDiff = Date.now() - parseInt(authTime);
            const eightHours = 8 * 60 * 60 * 1000;
            
            if (timeDiff < eightHours) {
                this.isAuthenticated = true;
                this.showDashboard();
            } else {
                // Auth expired
                this.clearAuthStatus();
                this.showLogin();
            }
        } else {
            this.showLogin();
        }
    }

    showLogin() {
        document.getElementById('loginScreen').classList.add('active');
        document.getElementById('dashboardScreen').classList.remove('active');
        document.getElementById('addClientScreen').classList.remove('active');
        document.getElementById('clientDetailScreen').classList.remove('active');
        
        // Focus password input
        setTimeout(() => {
            document.getElementById('passwordInput').focus();
        }, 300);
    }

    showDashboard() {
        document.getElementById('loginScreen').classList.remove('active');
        document.getElementById('dashboardScreen').classList.add('active');
        document.getElementById('addClientScreen').classList.remove('active');
        document.getElementById('clientDetailScreen').classList.remove('active');
        
        // Load dashboard data
        if (window.uiManager) {
            window.uiManager.loadDashboard();
        }
    }

    // Security helpers
    isUserAuthenticated() {
        return this.isAuthenticated;
    }

    requireAuth(callback) {
        if (this.isAuthenticated) {
            callback();
        } else {
            this.showLogin();
        }
    }
}

// Add CSS for shake animation
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
        20%, 40%, 60%, 80% { transform: translateX(5px); }
    }
`;
document.head.appendChild(style);

// Create global auth manager instance
window.authManager = new AuthManager();