// IndexedDB Database Management
class LuxeMotionDB {
    constructor() {
        this.dbName = 'LuxeMotionDB';
        this.version = 1;
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.version);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                // Create clients store
                if (!db.objectStoreNames.contains('clients')) {
                    const clientStore = db.createObjectStore('clients', {
                        keyPath: 'id',
                        autoIncrement: true
                    });
                    
                    clientStore.createIndex('name', 'name', { unique: false });
                    clientStore.createIndex('startDate', 'startDate', { unique: false });
                    clientStore.createIndex('carModel', 'carModel', { unique: false });
                }

                // Create settings store
                if (!db.objectStoreNames.contains('settings')) {
                    db.createObjectStore('settings', { keyPath: 'key' });
                }
            };
        });
    }

    async addClient(clientData) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['clients'], 'readwrite');
            const store = transaction.objectStore('clients');
            
            // Add timestamp
            clientData.createdAt = new Date().toISOString();
            
            const request = store.add(clientData);
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getAllClients() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['clients'], 'readonly');
            const store = transaction.objectStore('clients');
            const request = store.getAll();
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getClient(id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['clients'], 'readonly');
            const store = transaction.objectStore('clients');
            const request = store.get(id);
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async updateClient(clientData) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['clients'], 'readwrite');
            const store = transaction.objectStore('clients');
            
            // Add update timestamp
            clientData.updatedAt = new Date().toISOString();
            
            const request = store.put(clientData);
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async deleteClient(id) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['clients'], 'readwrite');
            const store = transaction.objectStore('clients');
            const request = store.delete(id);
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getSetting(key) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['settings'], 'readonly');
            const store = transaction.objectStore('settings');
            const request = store.get(key);
            
            request.onsuccess = () => resolve(request.result?.value);
            request.onerror = () => reject(request.error);
        });
    }

    async setSetting(key, value) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['settings'], 'readwrite');
            const store = transaction.objectStore('settings');
            const request = store.put({ key, value });
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Utility methods
    async getStats() {
        const clients = await this.getAllClients();
        const currentDate = new Date();
        
        let activeRentals = 0;
        let totalRevenue = 0;
        
        clients.forEach(client => {
            const startDate = new Date(client.startDate);
            const endDate = new Date(startDate);
            endDate.setDate(endDate.getDate() + parseInt(client.duration));
            
            if (currentDate >= startDate && currentDate <= endDate) {
                activeRentals++;
            }
            
            totalRevenue += parseFloat(client.totalPrice || 0);
        });
        
        return {
            totalClients: clients.length,
            activeRentals,
            totalRevenue
        };
    }

    // Search and filter methods
    async searchClients(query) {
        const clients = await this.getAllClients();
        const searchTerm = query.toLowerCase();
        
        return clients.filter(client => 
            client.name.toLowerCase().includes(searchTerm) ||
            client.carModel.toLowerCase().includes(searchTerm)
        );
    }

    async sortClients(sortBy) {
        const clients = await this.getAllClients();
        
        switch (sortBy) {
            case 'date-desc':
                return clients.sort((a, b) => new Date(b.startDate) - new Date(a.startDate));
            case 'date-asc':
                return clients.sort((a, b) => new Date(a.startDate) - new Date(b.startDate));
            case 'name-asc':
                return clients.sort((a, b) => a.name.localeCompare(b.name));
            case 'name-desc':
                return clients.sort((a, b) => b.name.localeCompare(a.name));
            default:
                return clients;
        }
    }
}

// Create global database instance
window.luxeDB = new LuxeMotionDB();