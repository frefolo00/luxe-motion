// UI Manager for handling interface interactions
class UIManager {
    constructor() {
        this.currentClient = null;
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Add client button
        document.getElementById('addClientBtn').addEventListener('click', () => {
            this.showAddClientForm();
        });

        // Back button
        document.getElementById('backBtn').addEventListener('click', () => {
            this.showDashboard();
        });

        // Back to list button
        document.getElementById('backToListBtn').addEventListener('click', () => {
            this.showDashboard();
        });

        // Save client button
        document.getElementById('saveClientBtn').addEventListener('click', () => {
            this.saveClient();
        });

        // Delete client button
        document.getElementById('deleteClientBtn').addEventListener('click', () => {
            this.deleteCurrentClient();
        });

        // Form calculations
        document.getElementById('duration').addEventListener('input', () => {
            this.calculateTotal();
        });

        document.getElementById('pricePerDay').addEventListener('input', () => {
            this.calculateTotal();
        });

        // Search and filter
        document.getElementById('searchFilter').addEventListener('input', (e) => {
            this.filterClients(e.target.value);
        });

        document.getElementById('sortFilter').addEventListener('change', (e) => {
            this.sortClients(e.target.value);
        });

        // Set default date to today
        document.getElementById('startDate').value = new Date().toISOString().split('T')[0];
    }

    async loadDashboard() {
        try {
            // Load statistics
            const stats = await window.luxeDB.getStats();
            document.getElementById('totalClients').textContent = stats.totalClients;
            document.getElementById('activeRentals').textContent = stats.activeRentals;
            document.getElementById('totalRevenue').textContent = `${stats.totalRevenue.toFixed(2)}€`;

            // Load clients list
            await this.loadClients();
        } catch (error) {
            console.error('Error loading dashboard:', error);
        }
    }

    async loadClients() {
        try {
            const clients = await window.luxeDB.getAllClients();
            this.displayClients(clients);
        } catch (error) {
            console.error('Error loading clients:', error);
        }
    }

    displayClients(clients) {
        const clientsList = document.getElementById('clientsList');
        const emptyState = document.getElementById('emptyState');

        if (clients.length === 0) {
            clientsList.style.display = 'none';
            emptyState.style.display = 'block';
            return;
        }

        clientsList.style.display = 'grid';
        emptyState.style.display = 'none';

        clientsList.innerHTML = clients.map(client => {
            const startDate = new Date(client.startDate);
            const endDate = new Date(startDate);
            endDate.setDate(endDate.getDate() + parseInt(client.duration));
            const isActive = new Date() >= startDate && new Date() <= endDate;
            
            return `
                <div class="client-card" onclick="window.uiManager.showClientDetail(${client.id})">
                    <div class="client-header">
                        ${client.facePhoto ? 
                            `<img src="${client.facePhoto}" alt="${client.name}" class="client-photo">` :
                            `<div class="client-photo"></div>`
                        }
                        <div class="client-info">
                            <h3>${client.name}</h3>
                            <p>${isActive ? '🟢 Activo' : '⚪ Finalizado'}</p>
                        </div>
                    </div>
                    <div class="client-details">
                        <div class="detail-item">
                            <label>Fecha Inicio</label>
                            <span>${new Date(client.startDate).toLocaleDateString()}</span>
                        </div>
                        <div class="detail-item">
                            <label>Duración</label>
                            <span>${client.duration} días</span>
                        </div>
                        <div class="detail-item">
                            <label>Fianza</label>
                            <span>${client.deposit}€</span>
                        </div>
                        <div class="detail-item">
                            <label>Total</label>
                            <span>${client.totalPrice}€</span>
                        </div>
                    </div>
                    <div class="car-badge">${client.carModel}</div>
                </div>
            `;
        }).join('');
    }

    showAddClientForm() {
        document.getElementById('dashboardScreen').classList.remove('active');
        document.getElementById('addClientScreen').classList.add('active');
        
        // Reset form
        this.resetClientForm();
        
        // Reset photos
        window.cameraManager.resetPhotos();
    }

    showDashboard() {
        document.getElementById('addClientScreen').classList.remove('active');
        document.getElementById('clientDetailScreen').classList.remove('active');
        document.getElementById('dashboardScreen').classList.add('active');
        
        // Reload dashboard data
        this.loadDashboard();
    }

    async showClientDetail(clientId) {
        try {
            const client = await window.luxeDB.getClient(clientId);
            if (!client) {
                alert('Cliente no encontrado');
                return;
            }

            this.currentClient = client;
            document.getElementById('clientDetailName').textContent = client.name;
            
            // Generate detail content
            const detailContent = this.generateClientDetailHTML(client);
            document.getElementById('clientDetailContent').innerHTML = detailContent;
            
            // Show detail screen
            document.getElementById('dashboardScreen').classList.remove('active');
            document.getElementById('clientDetailScreen').classList.add('active');
            
        } catch (error) {
            console.error('Error loading client detail:', error);
            alert('Error al cargar los detalles del cliente');
        }
    }

    generateClientDetailHTML(client) {
        const startDate = new Date(client.startDate);
        const endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + parseInt(client.duration));
        const isActive = new Date() >= startDate && new Date() <= endDate;

        return `
            <div class="detail-section">
                <h3>Información Personal</h3>
                <div class="detail-grid">
                    <div class="detail-item">
                        <label>Nombre Completo</label>
                        <span>${client.name}</span>
                    </div>
                    <div class="detail-item">
                        <label>Estado</label>
                        <span style="color: ${isActive ? '#00ff00' : '#888888'}">
                            ${isActive ? '🟢 Alquiler Activo' : '⚪ Alquiler Finalizado'}
                        </span>
                    </div>
                    <div class="detail-item">
                        <label>Fecha de Registro</label>
                        <span>${new Date(client.createdAt).toLocaleDateString()}</span>
                    </div>
                </div>
            </div>

            <div class="detail-section">
                <h3>Fotografías</h3>
                <div class="detail-photos">
                    ${client.facePhoto ? `
                        <div class="detail-photo">
                            <h4>Foto del Rostro</h4>
                            <img src="${client.facePhoto}" alt="Rostro" onclick="window.uiManager.openImageModal('${client.facePhoto}')">
                        </div>
                    ` : ''}
                    ${client.idFrontPhoto ? `
                        <div class="detail-photo">
                            <h4>DNI Frontal</h4>
                            <img src="${client.idFrontPhoto}" alt="DNI Frontal" onclick="window.uiManager.openImageModal('${client.idFrontPhoto}')">
                        </div>
                    ` : ''}
                    ${client.idBackPhoto ? `
                        <div class="detail-photo">
                            <h4>DNI Trasero</h4>
                            <img src="${client.idBackPhoto}" alt="DNI Trasero" onclick="window.uiManager.openImageModal('${client.idBackPhoto}')">
                        </div>
                    ` : ''}
                </div>
            </div>

            <div class="detail-section">
                <h3>Detalles del Alquiler</h3>
                <div class="detail-grid">
                    <div class="detail-item">
                        <label>Fecha de Inicio</label>
                        <span>${startDate.toLocaleDateString()}</span>
                    </div>
                    <div class="detail-item">
                        <label>Fecha de Fin</label>
                        <span>${endDate.toLocaleDateString()}</span>
                    </div>
                    <div class="detail-item">
                        <label>Duración</label>
                        <span>${client.duration} días</span>
                    </div>
                    <div class="detail-item">
                        <label>Coche Alquilado</label>
                        <span style="color: var(--primary-red); font-weight: 600;">${client.carModel}</span>
                    </div>
                    <div class="detail-item">
                        <label>Fianza Entregada</label>
                        <span>${client.deposit}€</span>
                    </div>
                    <div class="detail-item">
                        <label>Precio por Día</label>
                        <span>${client.pricePerDay}€</span>
                    </div>
                    <div class="detail-item">
                        <label>Total Facturado</label>
                        <span style="color: var(--primary-red); font-weight: 600; font-size: 1.1em;">${client.totalPrice}€</span>
                        <span style="color: var(--primary-blue); font-weight: 600; font-size: 1.1em;">${client.totalPrice}€</span>
                    </div>
                </div>
                
                <div style="margin-top: 20px;">
                    <button class="btn-primary" onclick="window.exportManager.exportClientToPDF(${client.id})">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                            <polyline points="7,10 12,15 17,10"/>
                            <line x1="12" y1="15" x2="12" y2="3"/>
                        </svg>
                        Exportar PDF
                    </button>
                </div>
            </div>
        `;
    }

    openImageModal(imageSrc) {
        // Create image modal
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-content" style="background: transparent; border: none; max-width: 90vw; max-height: 90vh;">
                <img src="${imageSrc}" style="width: 100%; height: auto; border-radius: 12px;">
            </div>
        `;
        
        modal.addEventListener('click', () => {
            document.body.removeChild(modal);
        });
        
        document.body.appendChild(modal);
    }

    async saveClient() {
        try {
            // Validate form
            const formData = this.getFormData();
            if (!this.validateFormData(formData)) {
                return;
            }

            showLoading('Guardando cliente...');

            // Get photos
            const photos = window.cameraManager.getCapturedPhotos();
            
            // Prepare client data
            const clientData = {
                ...formData,
                ...photos
            };

            // Save to database
            await window.luxeDB.addClient(clientData);
            
            hideLoading();
            
        this.showSuccessToast('Cliente guardado correctamente');
        setTimeout(() => this.showDashboard(), 1200);

            
        } catch (error) {
            console.error('Error saving client:', error);
            hideLoading();
            alert('Error al guardar el cliente');
        }
    }

    getFormData() {
        return {
            name: document.getElementById('clientName').value.trim(),
            startDate: document.getElementById('startDate').value,
            duration: parseInt(document.getElementById('duration').value),
            carModel: document.getElementById('carModel').value,
            deposit: parseFloat(document.getElementById('deposit').value),
            pricePerDay: parseFloat(document.getElementById('pricePerDay').value),
            totalPrice: parseFloat(document.getElementById('totalPrice').value)
        };
    }

    validateFormData(data) {
        if (!data.name) {
            alert('Por favor, ingresa el nombre del cliente');
            document.getElementById('clientName').focus();
            return false;
        }

        if (!data.startDate) {
            alert('Por favor, selecciona la fecha de inicio');
            document.getElementById('startDate').focus();
            return false;
        }

        if (!data.duration || data.duration < 1) {
            alert('Por favor, ingresa una duración válida');
            document.getElementById('duration').focus();
            return false;
        }

        if (!data.carModel) {
            alert('Por favor, selecciona el modelo del coche');
            document.getElementById('carModel').focus();
            return false;
        }

        if (isNaN(data.deposit) || data.deposit < 0) {
            alert('Por favor, ingresa una fianza válida');
            document.getElementById('deposit').focus();
            return false;
        }

        if (isNaN(data.pricePerDay) || data.pricePerDay <= 0) {
            alert('Por favor, ingresa un precio por día válido');
            document.getElementById('pricePerDay').focus();
            return false;
        }

        // Validate photos
        const photos = window.cameraManager.getCapturedPhotos();
        if (!photos.facePhoto) {
            alert('Por favor, captura la foto del rostro');
            return false;
        }

        if (!photos.idFrontPhoto) {
            alert('Por favor, captura la foto del DNI frontal');
            return false;
        }

        if (!photos.idBackPhoto) {
            alert('Por favor, captura la foto del DNI trasero');
            return false;
        }

        return true;
    }

    calculateTotal() {
        const duration = parseInt(document.getElementById('duration').value) || 0;
        const pricePerDay = parseFloat(document.getElementById('pricePerDay').value) || 0;
        const total = duration * pricePerDay;
        
        document.getElementById('totalPrice').value = total.toFixed(2);
    }

    resetClientForm() {
        document.getElementById('clientForm').reset();
        document.getElementById('startDate').value = new Date().toISOString().split('T')[0];
        document.getElementById('totalPrice').value = '';
    }

    async deleteCurrentClient() {
        if (!this.currentClient) return;

        const confirmed = confirm(`¿Estás seguro de que quieres eliminar el cliente "${this.currentClient.name}"? Esta acción no se puede deshacer.`);
        
        if (confirmed) {
            try {
                showLoading('Eliminando cliente...');
                await window.luxeDB.deleteClient(this.currentClient.id);
                hideLoading();
                alert('Cliente eliminado correctamente');
                this.showDashboard();
            } catch (error) {
                console.error('Error deleting client:', error);
                hideLoading();
                alert('Error al eliminar el cliente');
            }
        }
    }

    async filterClients(searchTerm) {
        try {
            let clients;
            if (searchTerm.trim()) {
                clients = await window.luxeDB.searchClients(searchTerm);
            } else {
                clients = await window.luxeDB.getAllClients();
            }
            this.displayClients(clients);
        } catch (error) {
            console.error('Error filtering clients:', error);
        }
    }

    async sortClients(sortBy) {
        try {
            const clients = await window.luxeDB.sortClients(sortBy);
            this.displayClients(clients);
        } catch (error) {
            console.error('Error sorting clients:', error);
        }
    }
}

// Global function for empty state button
function showAddClientForm() {
    window.uiManager.showAddClientForm();
}

// Create global UI manager instance
window.uiManager = new UIManager();
window.uiManager.showSuccessToast = function (message) {
    const toast = document.createElement('div');
    toast.className = 'success-toast';
    toast.innerHTML = `<span>✅ ${message}</span>`;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => document.body.removeChild(toast), 300);
        }, 2000);
    }, 100);
};
